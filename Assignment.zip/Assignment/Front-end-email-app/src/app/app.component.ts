import { Component } from '@angular/core';
import { FormGroup,FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {HttpService} from './http.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'email-app';
  counter = 60;
  btnDisabled = false;
  retry = 0;
  frm:FormGroup;
  emailInDisabled= false;
  interval:any;
  otpMessage:any= null;
  constructor(private httpService: HttpService) {
      this.frm = new FormGroup({
        email: new FormControl("", [Validators.required, Validators.pattern('^[A-Za-z0-9._%+-]+@dso.org.sg$')]),
        otp: new FormControl("")
      })
  }
  ngOnInit() {

  }
  sendotp() {
    this.btnDisabled = true;
    this.interval = setInterval(()=> {
      this.calculateDelay()
    }, 1000);
    const reqObj = {
      email: this.frm.get('email')?.value
    }
    this.httpService.sendOtp(reqObj).subscribe(res => {
      this.emailInDisabled = true;
      this.otpMessage = res.message;
    });
    
  }

  validateOtp() {
    const reqObj = {
      email: this.frm.get('email')?.value,
      otp: this.frm.get('otp')?.value
    }
    this.httpService.validateOtp(reqObj).subscribe(res => {
      if (!res.otpValidated) {
        this.retry = this.retry + 1;
        if (this.retry == 10) {
         setTimeout(() => {
            this.retry = 0;
         },10000)
        }
      } else {
        this.retry = 0;
      }
      console.log(res.message);
    });
  }
  calculateDelay() {
    this.counter = this.counter-1;
    if (this.counter == 0) {
      clearInterval(this.interval);
      this.counter = 30;
      this.btnDisabled = false;
    }
  }

}