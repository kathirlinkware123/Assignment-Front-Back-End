import {ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { HttpService } from './http.service';
import { HttpClient } from '@angular/common/http';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [ { provide: HttpService, useValue: HttpService } ],
    }).compileComponents();

  });

  beforeEach(()=> {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  })

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'email-app'`, () => {
    expect(component.title).toEqual('email-app');
  });

  it('should render title', () => {
    const inputElements = fixture.debugElement.nativeElement.querySelector("#frm").querySelectorAll('input');
    expect(inputElements.length).toEqual(2);
  });

  it('should check valid email like admin.hr@dso.org.sg ', () => {
    //inputEmail.value = "admin.hr@dso.org.sg";
    component.frm.get('email')?.setValue('admin.hr@dso.org.sg');
    const isFormvalid = component.frm.valid;
    fixture.whenStable().then(() => {
      expect(isFormvalid).toEqual(true);
    })
  });

  it('should check invalid email like tester1@proc.dso.org.sg  ', () => {
    component.frm.get('email')?.setValue('tester1@proc.dso.org.sg');
    const isFormvalid = component.frm.valid;
    fixture.whenStable().then(() => {
      expect(isFormvalid).toEqual(false);
    })
  });

});
