import { HttpService } from "./http.service";
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { TestBed } from "@angular/core/testing";

describe("HttpService", () => {
  let httpService: HttpService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let url = 'localhost:3000';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    httpService = TestBed.inject(HttpService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(httpService).toBeTruthy();
  });
 
  it("should have send OTP", () => {
    httpService.sendOtp({email:"test@gmail.com"}).subscribe((res) => {
        expect(res.message).toEqual("OTP Generated successfully: 121212");
      });

      const req = httpTestingController.expectOne({
        method: 'POST',
        url: `generateOtp`,
      });
  
      req.flush({message: "OTP Generated successfully: " + 121212});
  });

  it("should validate OTP", () => {
    const reqObj = {
        email: "test@gmail.com",
        otp: "121212"
      }
    httpService.validateOtp(reqObj).subscribe((res) => {
        expect(res.otpValidated).toEqual(true);
      });

      const req = httpTestingController.expectOne({
        method: 'POST',
        url: `validate`,
      });
  
      req.flush({
        otpValidated : true,
        message: "OTP validated successfully"
    });
  });
});