const express = require('express');
var bodyParser = require('body-parser')

const app = express();
var jsonParser = bodyParser.json()
var urlencodedParser = bodyParser.urlencoded({ extended: false })
const port = 8080;

const { createConnection } = require('mysql');

const connection = createConnection( {
    host: 'localhost',
    user: 'root',
    passowrd: '',
    database: 'test',
    connectionLimit: 10
});

function generateOTP() {
    var otp = Math.floor(Math.random() * 1000000);
    // add leading '0' if number less than six digit
    return (otp.toString().padStart(6, '0'))
  }

app.post('/generateOtp', jsonParser, (req, res)=> {

    let email = req.body.email;
    connection.query('select * from tb_validate where email = ?', email, function(err, results){
        if (err){ 
          throw err;
        }
        console.log(results);
        if(results.length && results[0].email) {
            res.send({message: "OTP Generated successfully: " + results[0].otp});
        } else {
            
            let otp = generateOTP();
            let sql = `INSERT INTO tb_validate 
                (email, otp) VALUES (?, ?);`; 

            connection.query(sql, [email, 
                otp], (err, rows) => {
                    if (err) throw err;
                    console.log("Row inserted with id = "
                        + rows.insertId);
                });
            res.send({message: "OTP Generated successfully: " + otp});
            }        
    })

});

app.post("/validate", jsonParser, (req, res) => {
    let email = req.body.email;
    let otp = req.body.otp;
    connection.query('select * from tb_validate where email = ? and otp = ?', [email, otp], function(err, results){
        if (err){ 
          throw err;
        }
        console.log(results);
        if(results.length) {
            res.send({
                otpValidated : true,
                message: "OTP validated successfully"
            });
            connection.query("delete from tb_validate where email = ?", email, function(err, results) {
                if (err){ 
                    throw err;
                  }
            })
        } else {
            res.send({
                otpValidated : false,
                message: "OTP enterd incorrect"
            });
        }      
    })
});

app.get("/server", (req, res) => {
    res.send("Server Running")
})
app.listen(port, ()=> {
    console.log("Server started port: " +port);
});
