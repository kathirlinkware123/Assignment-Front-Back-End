const { createConnection } = require('mysql');

const connection = createConnection( {
    host: 'localhost',
    user: 'root',
    passowrd: '',
    database: 'test',
    connectionLimit: 10
});
connection.connect(function(error) {
    if (!!error) 
        console.log("Error");
        else
        console.log("Success");
})
